const std = @import("std");
const zvm = @import("zvm");

pub fn main() anyerror!void {
    try zvm.timer.start();
    var cpu = zvm.core.cpu.CPU.init();
    var bus = zvm.mem.bus.Bus.init();
    var ram = zvm.components.ram.RAM.init();


    cpu.connect_bus(&bus);

    const cpu_device = zvm.device.device.Device.create(&ram, "RAM");
    bus.map_device(0x0, 0x8000, cpu_device);

    cpu.ipr.load_uint(@as(u32, 0xFFFFFFC));

    cpu.store(0xFFFF, 253);
    const val = cpu.load(0xFFFF);
    std.debug.print("RAM value at 0xFFFF: {d}", .{val});
}
